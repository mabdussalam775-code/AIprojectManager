"""Standalone seeder:  python seed_demo_users.py   (safe to re-run - never duplicates users)"""
from novaworks.seed import seed_demo_users

if __name__ == "__main__":
    n = seed_demo_users()
    print("Seeded {} new demo user(s). Password for every demo account: Demo123!".format(n))
