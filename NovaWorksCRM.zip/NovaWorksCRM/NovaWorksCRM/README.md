# NovaWorks CRM — AI Project Manager (Meeting → Execution)

**Infinity Hack '26 · AI Project Manager challenge**
Team: _<your team name>_  ·  Members: _<4 names>_

A desktop CRM for NovaWorks Technologies. The administrator pastes a meeting transcript; AI creates the
projects, tasks, owners, deadlines and estimated hours automatically; every user then sees only what their
role allows.

## Stack
| Layer | Technology |
|---|---|
| Frontend | **CustomTkinter** (dark / cyberpunk theme), Python 3.8+ |
| Backend logic | Plain Python modules (no web server needed) |
| Database | **SQLite** (stdlib) — indexed, foreign keys, triggers, transactions |
| AI | Any **OpenAI-compatible** chat model via the `openai` package, plus an offline fallback extractor |
| Security | PBKDF2-HMAC-SHA256 salted password hashes, server-side session tokens |

## Working features (all minimum requirements)
- Login / logout with the ten supplied demo accounts (no signup / reset / user management).
- **Admin**: dashboard with all project cards · **Create from Transcript** · team directory.
- **Manager**: only their own projects. **Agent**: *My Tasks* + related projects, only their own tasks.
- Project detail: client, manager, deadline, tasks (title, description, assigned agent, deadline, hours).
- Read-only team directory (names, roles, specializations, skills).
- Persistent saved projects/tasks (survive restart/refresh).
- Transcript flow: loading state, success summary, understandable errors, **correction + revalidate** screen.
- **Role-based access enforced in the data layer** (SQL-level filtering by the session user), not just by hiding buttons.
- **All-or-nothing save**: whole draft is validated first; saving runs in one DB transaction (rollback on any error).
- Repeated clicks are blocked while processing; duplicate projects are refused (also by a DB unique index).

## Setup & run (exact commands)
```bash
# 1. (optional) virtual environment
python -m venv venv
venv\Scripts\activate            # Windows        |   source venv/bin/activate   (macOS/Linux)

# 2. install
pip install -r requirements.txt

# 3. configure the AI key (skip to use the offline local extractor)
copy .env.example .env           # Windows        |   cp .env.example .env
#    then edit .env and set AI_API_KEY=...

# 4. database + demo accounts  (idempotent - safe to re-run; the app also does this on start-up)
python seed_demo_users.py

# 5. run
python main.py
```

### Environment variables (see `.env.example`)
`AI_API_KEY` · `AI_BASE_URL` · `AI_MODEL` · `AI_MODE` (`auto|llm|local`) · `AI_TIMEOUT_SECONDS` · `DATABASE_PATH`
(`OPENAI_API_KEY` / `OPENAI_BASE_URL` are accepted as aliases.)

## Demo accounts (fictional) — password for all: `Demo123!`
| Ref | Name | Email | Role |
|---|---|---|---|
| ADMIN | Admin | admin@novaworks.example | Administrator |
| PM01 | Ayesha Khan | ayesha@novaworks.example | Manager / Web PM |
| PM02 | Bilal Ahmed | bilal@novaworks.example | Manager / Mobile PM |
| PM03 | Hina Malik | hina@novaworks.example | Manager / AI PM |
| DEV01 | Ali Raza | ali@novaworks.example | Agent / Full-Stack |
| DEV02 | Hamza Shah | hamza@novaworks.example | Agent / Full-Stack |
| DEV03 | Sara Noor | sara@novaworks.example | Agent / App Developer |
| DEV04 | Usman Tariq | usman@novaworks.example | Agent / App Developer |
| DEV05 | Zain Abbas | zain@novaworks.example | Agent / AI Developer |
| DEV06 | Maryam Asif | maryam@novaworks.example | Agent / AI Developer |

The login screen also has a *quick-fill* dropdown for these accounts.

## Transcript testing steps (matches the judges' demo script)
1. `python main.py` → log in as `admin@novaworks.example`.
2. **Create from Transcript** → **LOAD SUPPLIED TRANSCRIPT** (or paste your own) → **CREATE FROM TRANSCRIPT**.
3. Expect **3 projects / 12 tasks**: UrbanCart 40 h · QuickServe 46 h · HelpDeskPro 38 h (124 h total).
4. Open a project → client, manager, deadline, tasks with owners/hours.
5. Log in as **Ayesha** → only UrbanCart. **Ali** → only his 3 tasks. **Hamza** → 2 tasks across 2 projects.
6. Restart the app → data is still there.
7. **Changed-input test**: dashboard → **CLEAR ALL**, edit the transcript (e.g. `Usman owns Mobile integration and
   testing: 12 hours, 23 October`), create again → only that task changes.
8. **Correction flow**: change an owner to `Kamran` → creation is blocked, nothing saved, issues listed;
   fix the JSON draft → **REVALIDATE & SAVE**.

## How the AI step works
`transcript + directory(id, name, role, skills)` → model → JSON draft → **strict validation** → one transaction.
- Passwords, hashes and e-mails are **never** sent to the AI (verified by a test).
- The prompt tells the model: final decisions win, ignore rejected features, only use existing users, null if unresolved.
- Validation rules: required fields, manager is a real MANAGER, assignee is a real AGENT, valid `YYYY-MM-DD`,
  task date ≤ project date, hours > 0, no duplicate task titles / projects. Names (e.g. "Ali") are resolved to ids.
- **Engines**: with `AI_API_KEY` set the LLM is used. Without a key (or `AI_MODE=local`) an **offline extractor**
  runs: it genuinely parses the transcript you give it (last-statement-wins, directory lookups), so it still reacts to
  modified input — but it understands the *final-recap* style of the supplied meeting only. For free-form
  transcripts use the LLM engine. An LLM failure is shown as an error; it never silently switches engine.

## Complexity (n projects, m tasks, U users, k rows returned)
| Operation | Time | Notes |
|---|---|---|
| Login | O(log U) + constant PBKDF2 cost | indexed e-mail lookup |
| Project detail / tasks | **O(log m + k)** | `idx_tasks_project`, `idx_tasks_assignee` |
| List projects (admin / manager / agent) | O(n) / O(log n + k) / O(log m + k) | `idx_projects_manager`; counts via indexed sub-queries |
| Validate AI draft | **O(P + T)** | one pass, O(1) dictionary lookups into the directory |
| Save draft | **O(P + T)** | one transaction, `executemany` |
| Space | O(P + T) for a draft, O(n + m) on disk, O(sessions) in memory | no N+1 queries anywhere |

Measured on 5,000 projects / 50,000 tasks (SQLite, sandbox): project detail **≈0.5 ms**; manager list (1,667 rows) ≈11 ms;
agent task list (8,315 rows) ≈31 ms.

## Project structure
```
main.py  seed_demo_users.py  sample_transcript.txt  .env.example  requirements.txt
novaworks/  config · security · database · seed · auth · access (RBAC) · validator
            ai_service · local_extractor · transcript_service
            ui/  app · login_view · projects_view · detail_view · tasks_view · team_view · transcript_view · theme · widgets
tests/test_system.py     # 23 tests: python -m unittest discover -s tests -v
```

## Tests
`python -m unittest discover -s tests -v` — seeding idempotency, hashing, login, answer-key match (3 projects / 12 tasks /
40-46-38 h), final-decision handling, changed-input test, rejected features absent, validation rules, rollback on DB
failure, LLM path (mocked), and the full role-based-access matrix (manager/agent isolation, forged tokens, admin-only).

## Submission notes
- **Database:** local SQLite. **Demo video:** _<link>_ (record steps 1–8 above). **Live link:** n/a — this is a desktop app.
- **Deployment platform / hosted DB:** not used (desktop MVP). Moving to hosted PostgreSQL (e.g. Aiven) would mean swapping
  the SQL in `database.py`, `access.py`, `transcript_service.py` for `psycopg2`; the layering keeps that change contained.

## Known limitations
- Desktop app: no browser/live deployment. SQLite is single-writer (fine for this MVP).
- The offline extractor is recap-format only; its task descriptions are simpler than the LLM's.
- Editing created projects/tasks after creation is not implemented (optional in the brief); use CLEAR ALL + re-create.
- Sessions live in memory for the running app (logout / restart ends them).
