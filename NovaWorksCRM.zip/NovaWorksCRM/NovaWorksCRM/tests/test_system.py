"""Run:  python -m unittest discover -s tests -v      (no GUI, no network, no API key needed)"""
import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from novaworks import access, ai_service, auth, config, database, security, seed, transcript_service, validator  # noqa: E402

security.ITERATIONS = 2000            # fast hashing for tests only
TRANSCRIPT = (ROOT / "sample_transcript.txt").read_text(encoding="utf-8")


class Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        config.DB_PATH = os.path.join(self._tmp.name, "test.db")
        config.AI_MODE = "local"
        seed.seed_demo_users()
        self.admin = auth.login("admin@novaworks.example", "Demo123!")["token"]

    def tearDown(self):
        self._tmp.cleanup()

    def tok(self, name):
        return auth.login("{}@novaworks.example".format(name), "Demo123!")["token"]

    def create(self, text=TRANSCRIPT):
        return transcript_service.create_from_transcript(self.admin, text)


class TestSeedAndLogin(Base):
    def test_seed_is_idempotent_with_ten_users(self):
        self.assertEqual(seed.seed_demo_users(), 0)
        with database.db() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM users").fetchone()[0], 10)
            roles = [r[0] for r in c.execute("SELECT role FROM users ORDER BY role")]
        self.assertEqual((roles.count("ADMIN"), roles.count("MANAGER"), roles.count("AGENT")), (1, 3, 6))

    def test_passwords_are_hashed(self):
        with database.db() as c:
            h = c.execute("SELECT password_hash FROM users WHERE id='DEV01'").fetchone()[0]
        self.assertNotIn("Demo123!", h)
        self.assertTrue(h.startswith("pbkdf2_sha256$"))

    def test_login_failures(self):
        for e, p in (("admin@novaworks.example", "wrong"), ("nobody@novaworks.example", "Demo123!"), ("", "")):
            with self.assertRaises(auth.AuthError):
                auth.login(e, p)

    def test_logout_invalidates_session(self):
        t = self.tok("ali")
        auth.logout(t)
        with self.assertRaises(auth.AuthError):
            access.get_projects(t)


class TestTranscriptConversion(Base):
    def test_supplied_transcript_matches_answer_key(self):
        r = self.create()
        self.assertEqual(r["status"], "created", r)
        self.assertEqual((r["project_count"], r["task_count"]), (3, 12))
        by = {p["name"]: p for p in access.get_projects(self.admin)}
        self.assertEqual({k: (v["deadline"], v["task_count"], v["total_hours"]) for k, v in by.items()}, {
            "UrbanCart Website": ("2026-10-20", 4, 40),
            "QuickServe Mobile App": ("2026-10-24", 4, 46),
            "HelpDeskPro AI Assistant": ("2026-10-22", 4, 38)})
        self.assertEqual(by["UrbanCart Website"]["manager_name"], "Ayesha Khan")
        self.assertEqual(by["QuickServe Mobile App"]["client_name"], "QuickServe Services")

    def test_final_decisions_and_rejected_items(self):
        self.create()
        tasks = {}
        for p in access.get_projects(self.admin):
            for t in access.get_tasks(self.admin, p["id"]):
                tasks[t["title"]] = t
        self.assertEqual(tasks["Website integration and testing"]["deadline"], "2026-10-19")
        self.assertEqual(tasks["Mobile integration and testing"]["estimated_hours"], 10)
        self.assertEqual(tasks["Assistant evaluation and testing"]["assignee_name"], "Maryam Asif")
        everything = " ".join(t["title"].lower() + t["assignee_name"].lower() for t in tasks.values())
        for banned in ("payment", "inventory", "map", "email", "kamran"):
            self.assertNotIn(banned, everything)

    def test_changed_input_changes_only_that_task(self):
        self.create()
        base = {t["title"]: (t["deadline"], t["estimated_hours"]) for p in access.get_projects(self.admin)
                for t in access.get_tasks(self.admin, p["id"])}
        with database.db() as c:
            c.execute("DELETE FROM tasks"); c.execute("DELETE FROM projects")
        modified = TRANSCRIPT.replace("Usman owns Mobile integration and testing: 10 hours, 22 October",
                                      "Usman owns Mobile integration and testing: 12 hours, 23 October")
        self.assertEqual(self.create(modified)["status"], "created")
        new = {t["title"]: (t["deadline"], t["estimated_hours"]) for p in access.get_projects(self.admin)
               for t in access.get_tasks(self.admin, p["id"])}
        self.assertEqual(new["Mobile integration and testing"], ("2026-10-23", 12))
        for k in base:
            if k != "Mobile integration and testing":
                self.assertEqual(base[k], new[k])

    def test_empty_transcript_rejected(self):
        with self.assertRaises(transcript_service.TranscriptError):
            self.create("   ")

    def test_unusable_transcript_is_an_error_and_saves_nothing(self):
        with self.assertRaises(ai_service.AIError):
            self.create("We talked about lunch.")
        self.assertEqual(access.get_projects(self.admin), [])

    def test_repeat_click_does_not_duplicate(self):
        self.create()
        r = self.create()
        self.assertEqual(r["status"], "needs_correction")
        self.assertEqual(len(access.get_projects(self.admin)), 3)


class TestValidationAndAtomicity(Base):
    def draft(self):
        return {"projects": [{"name": "P", "clientName": "C", "description": "d", "managerId": "PM01",
                              "deadline": "2026-10-20", "tasks": [
                                  {"title": "T1", "description": "", "assigneeId": "DEV01",
                                   "deadline": "2026-10-12", "estimatedHours": 5}]}]}

    def test_unresolved_person_blocks_save_then_correction_works(self):
        d = self.draft(); d["projects"][0]["tasks"][0]["assigneeId"] = "Kamran"
        r = transcript_service.save_draft(self.admin, d)
        self.assertEqual(r["status"], "needs_correction")
        self.assertIn("Kamran", r["issues"][0]["message"])
        self.assertEqual(access.get_projects(self.admin), [])
        r["draft"]["projects"][0]["tasks"][0]["assigneeId"] = "DEV02"
        self.assertEqual(transcript_service.save_draft(self.admin, r["draft"])["status"], "created")

    def test_rules(self):
        users = transcript_service.load_directory(database.connect())
        cases = [
            (lambda d: d["projects"][0]["tasks"][0].update(estimatedHours=0), "estimated hours"),
            (lambda d: d["projects"][0]["tasks"][0].update(estimatedHours=True), "estimated hours"),
            (lambda d: d["projects"][0]["tasks"][0].update(deadline="2026-10-21"), "after the project deadline"),
            (lambda d: d["projects"][0]["tasks"][0].update(deadline="12/10/2026"), "valid YYYY-MM-DD"),
            (lambda d: d["projects"][0].update(managerId="DEV01"), "not a MANAGER"),
            (lambda d: d["projects"][0]["tasks"][0].update(assigneeId="PM01"), "not an AGENT"),
            (lambda d: d["projects"][0].update(deadline=None), "deadline"),
            (lambda d: d["projects"][0].update(clientName=""), "client name"),
        ]
        for mutate, expected in cases:
            d = self.draft(); mutate(d)
            _, issues = validator.validate_draft(d, users)
            self.assertTrue(any(expected in i["message"] for i in issues), (expected, issues))
        _, issues = validator.validate_draft(self.draft(), users)
        self.assertEqual(issues, [])

    def test_names_are_resolved_to_ids(self):
        users = transcript_service.load_directory(database.connect())
        d = self.draft(); d["projects"][0]["managerId"] = "Ayesha"; d["projects"][0]["tasks"][0]["assigneeId"] = "Ali Raza"
        norm, issues = validator.validate_draft(d, users)
        self.assertEqual(issues, [])
        self.assertEqual((norm["projects"][0]["managerId"], norm["projects"][0]["tasks"][0]["assigneeId"]), ("PM01", "DEV01"))

    def test_database_failure_rolls_back_everything(self):
        clean = self.draft()["projects"]
        bad = {"name": "Second", "clientName": "C2", "description": "", "managerId": "PM02", "deadline": "2026-10-20",
               "tasks": [{"title": "ok", "description": "", "assigneeId": "DEV01", "deadline": "2026-10-10", "estimatedHours": 1},
                         {"title": "boom", "description": "", "assigneeId": "PM01", "deadline": "2026-10-10", "estimatedHours": 1}]}
        with database.db() as conn:
            with self.assertRaises(Exception):
                transcript_service._save(conn, {"projects": clean + [bad]})
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM projects").fetchone()[0], 0)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0], 0)

    def test_json_parsing_tolerates_fences_and_chatter(self):
        self.assertEqual(ai_service.parse_json_loose('```json\n{"projects": []}\n```'), {"projects": []})
        self.assertEqual(ai_service.parse_json_loose('Sure! {"projects": []} Done.'), {"projects": []})
        with self.assertRaises(ai_service.AIError):
            ai_service.parse_json_loose("no json here")

    def test_llm_path_is_used_when_mocked(self):
        config.AI_MODE = "llm"; config.AI_API_KEY = "x"
        called = {}
        def fake(transcript, directory):
            called["dir_keys"] = set(directory[0].keys())
            return {"projects": [{"name": "Mock", "clientName": "M", "description": "", "managerId": "PM03",
                                  "deadline": "2026-11-01", "tasks": [{"title": "A", "description": "", "assigneeId": "DEV05",
                                                                        "deadline": "2026-10-30", "estimatedHours": 3}]}]}
        orig, ai_service._call_llm = ai_service._call_llm, fake
        try:
            r = self.create("anything")
        finally:
            ai_service._call_llm = orig; config.AI_API_KEY = ""
        self.assertEqual(r["status"], "created")
        self.assertEqual(called["dir_keys"], {"id", "name", "email", "role", "specialization", "skills"})


class TestRoleBasedAccess(Base):
    def setUp(self):
        super().setUp()
        self.create()
        self.pid = {p["name"]: p["id"] for p in access.get_projects(self.admin)}

    def test_manager_sees_only_own_project(self):
        t = self.tok("ayesha")
        self.assertEqual([p["name"] for p in access.get_projects(t)], ["UrbanCart Website"])
        self.assertEqual(len(access.get_tasks(t, self.pid["UrbanCart Website"])), 4)
        for other in ("QuickServe Mobile App", "HelpDeskPro AI Assistant"):
            with self.assertRaises(access.AccessDenied):
                access.get_project_by_id(t, self.pid[other])
            with self.assertRaises(access.AccessDenied):
                access.get_tasks(t, self.pid[other])

    def test_agent_sees_only_own_tasks(self):
        t = self.tok("ali")
        mine = access.get_my_tasks(t)
        self.assertEqual(len(mine), 3)
        self.assertEqual({x["title"] for x in mine}, {"Product catalog UI", "Demo cart UI", "Website integration and testing"})
        proj = access.get_project_by_id(t, self.pid["UrbanCart Website"])
        self.assertEqual(len(proj["tasks"]), 3)                       # NOT Hamza's API task
        self.assertNotIn("Product and cart APIs", [x["title"] for x in proj["tasks"]])
        self.assertEqual(proj["manager_name"], "Ayesha Khan")
        with self.assertRaises(access.AccessDenied):
            access.get_project_by_id(t, self.pid["QuickServe Mobile App"])
        with self.assertRaises(access.AccessDenied):
            access.get_tasks(t, self.pid["HelpDeskPro AI Assistant"])

    def test_hamza_two_tasks_across_two_projects(self):
        t = self.tok("hamza")
        self.assertEqual(sorted(x["title"] for x in access.get_my_tasks(t)), ["Booking and account APIs", "Product and cart APIs"])
        self.assertEqual(len(access.get_projects(t)), 2)

    def test_only_admin_can_create_or_clear(self):
        for who in ("ayesha", "ali"):
            t = self.tok(who)
            with self.assertRaises(access.AccessDenied):
                transcript_service.create_from_transcript(t, TRANSCRIPT)
            with self.assertRaises(access.AccessDenied):
                transcript_service.save_draft(t, {"projects": []})
            with self.assertRaises(access.AccessDenied):
                access.clear_all_projects(t)

    def test_forged_token_and_bad_ids_rejected(self):
        with self.assertRaises(auth.AuthError):
            access.get_projects("forged-token")
        with self.assertRaises(access.AccessDenied):
            access.get_project_by_id(self.admin, "1 OR 1=1")
        with self.assertRaises(access.AccessDenied):
            access.get_project_by_id(self.admin, 99999)

    def test_directory_never_leaks_credentials(self):
        d = access.get_team_directory(self.tok("sara"))
        self.assertEqual(len(d), 10)
        self.assertEqual(set(d[0].keys()), {"id", "name", "role", "specialization", "skills"})

    def test_data_survives_new_connection(self):          # persistence ("refresh")
        self.assertEqual(len(access.get_projects(self.admin)), 3)
        self.assertEqual(sum(p["task_count"] for p in access.get_projects(self.admin)), 12)


if __name__ == "__main__":
    unittest.main()
