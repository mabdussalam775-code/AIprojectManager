"""AI engine. Sends the transcript + team directory (id, name, role, skills - NEVER passwords or
e-mails) to an OpenAI-compatible chat model and returns the parsed JSON draft.

AI_MODE=auto  -> LLM when AI_API_KEY is set, otherwise the offline local extractor
AI_MODE=llm   -> LLM only (error if no key)      AI_MODE=local -> local extractor only
An LLM failure is reported as an error - it never silently degrades into a different engine."""
from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Tuple

from . import config, local_extractor


class AIError(Exception):
    pass


SYSTEM_PROMPT = """You are the planning engine of a Project Management CRM for NovaWorks Technologies.
Convert the meeting transcript into projects and tasks. Reply with ONE JSON object only - no prose,
no markdown fences.

RULES
1. FINAL AGREED DECISIONS WIN. If a deadline, estimate, owner or delivery date is revised later in the
   meeting, output only the LAST agreed value. Never output superseded values. A closing recap is
   authoritative.
2. One project per client engagement. Keep projects separate. One task per distinct piece of work;
   never merge tasks (even with the same owner) and never split one task into sub-tasks.
3. IGNORE rejected, excluded, deferred or "future work" features (e.g. payments, inventory, maps, real
   e-mail sending). They must not become tasks and must not appear as scope.
4. Use ONLY people from the supplied directory. managerId must be the id of a user whose role is
   MANAGER; assigneeId must be the id of a user whose role is AGENT. Match people by name. Never invent
   people. Clients, end users and outsiders mentioned in the meeting are NOT employees and must never
   be assigned work. If a required person cannot be resolved, use null.
5. Dates are YYYY-MM-DD. Use the year of the meeting when none is stated. A project deadline is the
   final confirmed delivery date. Every task deadline must be on or before its project deadline. If a
   required date cannot be determined, use null.
6. estimatedHours is developer EFFORT in hours (a positive number), not calendar days. Do not create
   management-hour tasks.
7. Use the exact task names agreed in the meeting. Write a concise 1-2 sentence description from what
   was said. Project description: the agreed scope, including explicit boundaries (e.g. "demo only").
8. Do not output costs, rates, progress, or ids for projects/tasks.

OUTPUT SHAPE
{"projects":[{"name":"","clientName":"","description":"","managerId":"PM01","deadline":"YYYY-MM-DD",
"tasks":[{"title":"","description":"","assigneeId":"DEV01","deadline":"YYYY-MM-DD","estimatedHours":12}]}]}"""


def mode() -> str:
    m = config.AI_MODE
    if m == "local":
        return "local"
    if m == "llm":
        return "llm"
    return "llm" if config.AI_API_KEY else "local"


def engine_label() -> str:
    if mode() == "llm":
        return "LLM  ·  {}".format(config.AI_MODEL)
    return "LOCAL EXTRACTOR  ·  offline (set AI_API_KEY for the LLM engine)"


def parse_json_loose(text: str) -> Dict[str, Any]:
    """Accept clean JSON, ```json fenced JSON, or JSON surrounded by chatter."""
    s = (text or "").strip()
    s = re.sub(r"^```(?:json)?\s*|\s*```$", "", s, flags=re.I).strip()
    for candidate in (s, s[s.find("{"):s.rfind("}") + 1] if "{" in s and "}" in s else ""):
        if not candidate:
            continue
        try:
            data = json.loads(candidate)
        except ValueError:
            continue
        if isinstance(data, dict):
            return data
    raise AIError("The AI did not return valid JSON. Please try again.")


def _call_llm(transcript: str, directory: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not config.AI_API_KEY:
        raise AIError("AI_MODE=llm but no AI_API_KEY is set. Add it to your .env file.")
    try:
        import openai
        from openai import OpenAI
    except ImportError:
        raise AIError("The 'openai' package is missing. Run: pip install openai")

    kwargs: Dict[str, Any] = {"api_key": config.AI_API_KEY, "timeout": config.AI_TIMEOUT, "max_retries": 2}
    if config.AI_BASE_URL:
        kwargs["base_url"] = config.AI_BASE_URL
    client = OpenAI(**kwargs)

    year = re.search(r"\b(20\d{2})\b", transcript)
    safe_dir = [{"id": u["id"], "name": u["name"], "role": u["role"],
                 "specialization": u["specialization"], "skills": u["skills"]} for u in directory]
    user_msg = ("TEAM DIRECTORY (the only people that exist):\n{}\n\nDEFAULT YEAR: {}\n\n"
                "MEETING TRANSCRIPT:\n{}").format(
        json.dumps(safe_dir, ensure_ascii=False), year.group(1) if year else config.DEFAULT_YEAR, transcript)
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": user_msg}]

    def ask(json_mode: bool):
        extra = {"response_format": {"type": "json_object"}} if json_mode else {}
        return client.chat.completions.create(model=config.AI_MODEL, messages=messages, temperature=0, **extra)

    try:
        try:
            resp = ask(True)
        except Exception as exc:                       # some providers reject response_format
            if "response_format" in str(exc).lower() or "json_object" in str(exc).lower():
                resp = ask(False)
            else:
                raise
    except Exception as exc:
        name = type(exc).__name__
        if name == "AuthenticationError":
            raise AIError("The AI service rejected the API key. Check AI_API_KEY.")
        if name in ("APIConnectionError", "APITimeoutError"):
            raise AIError("Could not reach the AI service. Check your internet connection and AI_BASE_URL.")
        if name == "RateLimitError":
            raise AIError("The AI service is rate-limiting or out of quota. Try again shortly.")
        raise AIError("AI request failed ({}): {}".format(name, str(exc)[:300]))

    content = resp.choices[0].message.content if resp.choices else None
    if not content:
        raise AIError("The AI returned an empty response. Please try again.")
    return parse_json_loose(content)


def extract_draft(transcript: str, directory: List[Dict[str, Any]]) -> Tuple[Dict[str, Any], str]:
    """Return (draft, engine_label). Raises AIError on failure - nothing is saved by this step."""
    if mode() == "llm":
        return _call_llm(transcript, directory), "LLM ({})".format(config.AI_MODEL)
    try:
        return local_extractor.extract(transcript, directory, config.DEFAULT_YEAR), "Local extractor"
    except local_extractor.ExtractionError as exc:
        raise AIError(str(exc))
