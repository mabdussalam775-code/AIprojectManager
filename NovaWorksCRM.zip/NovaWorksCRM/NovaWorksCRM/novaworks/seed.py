"""Demo-account seeder. Idempotent: re-running never duplicates users."""
from __future__ import annotations

import json

from . import config, security
from .database import db, init_db

DEMO_ACCOUNTS = [
    ("ADMIN", "Admin",        "admin@novaworks.example",  "ADMIN",   "Administrator",     ["Company overview", "Transcript creation"]),
    ("PM01",  "Ayesha Khan",  "ayesha@novaworks.example", "MANAGER", "Manager / Web PM",  ["Web projects", "Client coordination"]),
    ("PM02",  "Bilal Ahmed",  "bilal@novaworks.example",  "MANAGER", "Manager / Mobile PM", ["Mobile projects", "Delivery planning"]),
    ("PM03",  "Hina Malik",   "hina@novaworks.example",   "MANAGER", "Manager / AI PM",   ["AI projects", "Requirement review"]),
    ("DEV01", "Ali Raza",     "ali@novaworks.example",    "AGENT",   "Agent / Full-Stack", ["React", "Frontend integration"]),
    ("DEV02", "Hamza Shah",   "hamza@novaworks.example",  "AGENT",   "Agent / Full-Stack", ["Node.js", "Databases", "APIs"]),
    ("DEV03", "Sara Noor",    "sara@novaworks.example",   "AGENT",   "Agent / App Developer", ["Flutter", "Mobile UI"]),
    ("DEV04", "Usman Tariq",  "usman@novaworks.example",  "AGENT",   "Agent / App Developer", ["Flutter", "Integration", "Testing"]),
    ("DEV05", "Zain Abbas",   "zain@novaworks.example",   "AGENT",   "Agent / AI Developer", ["LLMs", "Extraction", "Prompts"]),
    ("DEV06", "Maryam Asif",  "maryam@novaworks.example", "AGENT",   "Agent / AI Developer", ["Retrieval", "Document processing"]),
]


def seed_demo_users() -> int:
    """Upsert by unique email. Returns number of NEW users inserted."""
    init_db()
    inserted = 0
    with db() as conn:
        for uid, name, email, role, spec, skills in DEMO_ACCOUNTS:
            exists = conn.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone()
            if exists:  # refresh profile only; never touches the stored password hash
                conn.execute("UPDATE users SET name=?, role=?, specialization=?, skills=? WHERE email=?",
                             (name, role, spec, json.dumps(skills), email))
            else:
                conn.execute(
                    "INSERT INTO users (id,name,email,password_hash,role,specialization,skills) VALUES (?,?,?,?,?,?,?)",
                    (uid, name, email, security.hash_password(config.DEMO_PASSWORD), role, spec, json.dumps(skills)))
                inserted += 1
    return inserted


if __name__ == "__main__":
    n = seed_demo_users()
    print("Seeded {} new demo user(s); {} accounts total.".format(n, len(DEMO_ACCOUNTS)))
