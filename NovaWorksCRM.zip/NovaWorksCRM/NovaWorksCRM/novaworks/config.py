"""Central configuration. Values come from environment variables or a local .env file."""
from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_env_file(path: Path) -> None:
    """Tiny .env reader (no extra dependency). Real environment variables win."""
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_env_file(BASE_DIR / ".env")

# --- Database -------------------------------------------------------------
DB_PATH = os.environ.get("DATABASE_PATH") or str(BASE_DIR / "data" / "novaworks.db")

# --- AI engine (any OpenAI-compatible endpoint) -----------------------------
AI_API_KEY = os.environ.get("AI_API_KEY") or os.environ.get("OPENAI_API_KEY") or ""
AI_BASE_URL = os.environ.get("AI_BASE_URL") or os.environ.get("OPENAI_BASE_URL") or ""
AI_MODEL = os.environ.get("AI_MODEL") or "gpt-4o-mini"
AI_MODE = (os.environ.get("AI_MODE") or "auto").strip().lower()  # auto | llm | local
AI_TIMEOUT = float(os.environ.get("AI_TIMEOUT_SECONDS") or 90)

# --- Demo ---------------------------------------------------------------------
DEMO_PASSWORD = "Demo123!"
DEFAULT_YEAR = 2026  # meeting year, used when a transcript date has no year
