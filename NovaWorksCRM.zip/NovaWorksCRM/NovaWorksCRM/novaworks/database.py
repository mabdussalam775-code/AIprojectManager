"""SQLite layer: schema, indexes, DB-level integrity rules and an all-or-nothing transaction helper.

Indexes make every access-controlled query O(log n + k):
  idx_projects_manager  -> manager's project list
  idx_tasks_project     -> tasks of a project
  idx_tasks_assignee    -> agent's tasks / distinct projects
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id             TEXT PRIMARY KEY,
    name           TEXT NOT NULL,
    email          TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash  TEXT NOT NULL,
    role           TEXT NOT NULL CHECK (role IN ('ADMIN','MANAGER','AGENT')),
    specialization TEXT NOT NULL DEFAULT '',
    skills         TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL CHECK (length(trim(name)) > 0),
    client_name TEXT NOT NULL CHECK (length(trim(client_name)) > 0),
    description TEXT NOT NULL DEFAULT '',
    manager_id  TEXT NOT NULL REFERENCES users(id),
    deadline    TEXT NOT NULL CHECK (deadline GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_projects_manager ON projects(manager_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_projects_unique
    ON projects(name COLLATE NOCASE, client_name COLLATE NOCASE);

CREATE TABLE IF NOT EXISTS tasks (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id      INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    title           TEXT NOT NULL CHECK (length(trim(title)) > 0),
    description     TEXT NOT NULL DEFAULT '',
    assignee_id     TEXT NOT NULL REFERENCES users(id),
    deadline        TEXT NOT NULL CHECK (deadline GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
    estimated_hours REAL NOT NULL CHECK (estimated_hours > 0)
);
CREATE INDEX IF NOT EXISTS idx_tasks_project  ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_assignee ON tasks(assignee_id, project_id);

-- Defence in depth: the database itself refuses wrong references.
CREATE TRIGGER IF NOT EXISTS trg_project_manager_role BEFORE INSERT ON projects
WHEN (SELECT role FROM users WHERE id = NEW.manager_id) IS NOT 'MANAGER'
BEGIN SELECT RAISE(ABORT, 'managerId must reference a MANAGER'); END;

CREATE TRIGGER IF NOT EXISTS trg_task_assignee_role BEFORE INSERT ON tasks
WHEN (SELECT role FROM users WHERE id = NEW.assignee_id) IS NOT 'AGENT'
BEGIN SELECT RAISE(ABORT, 'assigneeId must reference an AGENT'); END;

CREATE TRIGGER IF NOT EXISTS trg_task_deadline BEFORE INSERT ON tasks
WHEN NEW.deadline > (SELECT deadline FROM projects WHERE id = NEW.project_id)
BEGIN SELECT RAISE(ABORT, 'task deadline is after the project deadline'); END;
"""


def connect() -> sqlite3.Connection:
    Path(config.DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(config.DB_PATH, timeout=15, isolation_level=None)  # manual transactions
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def db():
    """One short-lived connection per operation -> safe to use from worker threads."""
    conn = connect()
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def transaction(conn: sqlite3.Connection):
    """All-or-nothing block: commit on success, rollback on ANY exception."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    else:
        conn.execute("COMMIT")


def init_db() -> None:
    conn = connect()
    try:
        try:
            conn.execute("PRAGMA journal_mode = WAL")
        except sqlite3.Error:
            pass
        conn.executescript(SCHEMA)
    finally:
        conn.close()
