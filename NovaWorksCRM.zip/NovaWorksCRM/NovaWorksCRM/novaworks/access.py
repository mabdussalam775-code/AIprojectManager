"""Role-based data access. EVERY read goes through here and is filtered in SQL by the session user,
so restrictions hold for direct data requests, not just for what the UI chooses to show.

  ADMIN   -> all projects / tasks
  MANAGER -> only projects where manager_id == me (all tasks of those projects)
  AGENT   -> only projects containing MY tasks, and only MY tasks inside them

Complexity (n projects, m tasks, k = rows returned): every query uses an index -> O(log n + k).
"""
from __future__ import annotations

import json
from typing import Any, Dict, List

from . import auth
from .database import db, transaction


class AccessDenied(Exception):
    pass


_NOT_FOUND = "Project not found, or you do not have access to it."


def _visible_projects(conn, user: Dict[str, Any], project_id: int = None) -> List[Dict[str, Any]]:
    role, params = user["role"], []
    cols = ("p.id, p.name, p.client_name, p.description, p.manager_id, "
            "m.name AS manager_name, p.deadline")
    if role == "AGENT":
        # distinct projects containing my tasks; counts/hours reflect ONLY my tasks
        sql = ("SELECT " + cols + ", COUNT(t.id) AS task_count, "
               "COALESCE(SUM(t.estimated_hours),0) AS total_hours "
               "FROM tasks t JOIN projects p ON p.id = t.project_id "
               "JOIN users m ON m.id = p.manager_id WHERE t.assignee_id = ?")
        params.append(user["id"])
        if project_id is not None:
            sql += " AND p.id = ?"
            params.append(project_id)
        sql += " GROUP BY p.id ORDER BY p.deadline, p.id"
    elif role in ("ADMIN", "MANAGER"):
        sql = ("SELECT " + cols + ", "
               "(SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id) AS task_count, "
               "(SELECT COALESCE(SUM(t.estimated_hours),0) FROM tasks t WHERE t.project_id = p.id) AS total_hours "
               "FROM projects p JOIN users m ON m.id = p.manager_id")
        where = []
        if role == "MANAGER":
            where.append("p.manager_id = ?")
            params.append(user["id"])
        if project_id is not None:
            where.append("p.id = ?")
            params.append(project_id)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY p.deadline, p.id"
    else:
        raise AccessDenied("Unknown role.")
    return [dict(r) for r in conn.execute(sql, params)]


def _tasks_for(conn, user: Dict[str, Any], project_id: int) -> List[Dict[str, Any]]:
    sql = ("SELECT t.id, t.project_id, t.title, t.description, t.assignee_id, a.name AS assignee_name, "
           "t.deadline, t.estimated_hours FROM tasks t JOIN users a ON a.id = t.assignee_id "
           "WHERE t.project_id = ?")
    params: List[Any] = [project_id]
    if user["role"] == "AGENT":
        sql += " AND t.assignee_id = ?"          # never another agent's task
        params.append(user["id"])
    sql += " ORDER BY t.deadline, t.id"
    return [dict(r) for r in conn.execute(sql, params)]


def _as_id(project_id) -> int:
    try:
        return int(project_id)
    except (TypeError, ValueError):
        raise AccessDenied(_NOT_FOUND)


# ----------------------------------------------------------------------------- public API
def get_projects(token: str) -> List[Dict[str, Any]]:
    with db() as conn:
        return _visible_projects(conn, auth.user_for_token(conn, token))


def get_tasks(token: str, project_id) -> List[Dict[str, Any]]:
    pid = _as_id(project_id)
    with db() as conn:
        user = auth.user_for_token(conn, token)
        if not _visible_projects(conn, user, pid):
            raise AccessDenied(_NOT_FOUND)
        return _tasks_for(conn, user, pid)


def get_project_by_id(token: str, project_id) -> Dict[str, Any]:
    pid = _as_id(project_id)
    with db() as conn:
        user = auth.user_for_token(conn, token)
        rows = _visible_projects(conn, user, pid)
        if not rows:
            raise AccessDenied(_NOT_FOUND)
        project = rows[0]
        project["tasks"] = _tasks_for(conn, user, pid)
        project["scope"] = "own-tasks-only" if user["role"] == "AGENT" else "full"
        return project


def get_my_tasks(token: str) -> List[Dict[str, Any]]:
    """Agent 'My Tasks' screen: tasks assigned to me, with their project context."""
    with db() as conn:
        user = auth.user_for_token(conn, token)
        if user["role"] != "AGENT":
            raise AccessDenied("Only developer agents have a My Tasks list.")
        rows = conn.execute(
            "SELECT t.id, t.project_id, t.title, t.description, t.deadline, t.estimated_hours, "
            "p.name AS project_name, p.client_name, m.name AS manager_name "
            "FROM tasks t JOIN projects p ON p.id = t.project_id JOIN users m ON m.id = p.manager_id "
            "WHERE t.assignee_id = ? ORDER BY t.deadline, t.id", (user["id"],))
        return [dict(r) for r in rows]


def get_team_directory(token: str) -> List[Dict[str, Any]]:
    """Read-only directory: names, roles, specializations, skills. Never e-mails or password hashes."""
    with db() as conn:
        auth.user_for_token(conn, token)
        rows = conn.execute(
            "SELECT id, name, role, specialization, skills FROM users ORDER BY "
            "CASE role WHEN 'ADMIN' THEN 0 WHEN 'MANAGER' THEN 1 ELSE 2 END, id")
        return [{"id": r["id"], "name": r["name"], "role": r["role"],
                 "specialization": r["specialization"], "skills": json.loads(r["skills"] or "[]")}
                for r in rows]


def clear_all_projects(token: str) -> int:
    """Admin-only demo helper: remove all projects/tasks (users are kept). Returns projects removed."""
    with db() as conn:
        user = auth.user_for_token(conn, token)
        if user["role"] != "ADMIN":
            raise AccessDenied("Only the administrator can clear projects.")
        with transaction(conn):
            n = conn.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
            conn.execute("DELETE FROM tasks")
            conn.execute("DELETE FROM projects")
        return n
