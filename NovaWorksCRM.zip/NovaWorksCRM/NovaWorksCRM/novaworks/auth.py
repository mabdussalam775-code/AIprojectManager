"""Login / session handling. The current user is ALWAYS derived from the server-side session token,
never from a caller-supplied role or user id."""
from __future__ import annotations

import json
import secrets
import threading
from typing import Any, Dict

from . import security
from .database import db


class AuthError(Exception):
    pass


_sessions: Dict[str, str] = {}   # token -> user id      (space O(active sessions))
_lock = threading.Lock()


def _public_user(row) -> Dict[str, Any]:
    return {
        "id": row["id"], "name": row["name"], "email": row["email"], "role": row["role"],
        "specialization": row["specialization"], "skills": json.loads(row["skills"] or "[]"),
    }


def login(email: str, password: str) -> Dict[str, Any]:
    """Return {'token', 'user'} or raise AuthError. Same message for unknown email / wrong password."""
    email = (email or "").strip()
    if not email or not password:
        raise AuthError("Enter your email and password.")
    with db() as conn:
        row = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()   # O(log n)
    if row is None:
        security.burn_time(password)
        raise AuthError("Invalid email or password.")
    if not security.verify_password(password, row["password_hash"]):
        raise AuthError("Invalid email or password.")
    token = secrets.token_hex(24)
    with _lock:
        _sessions[token] = row["id"]
    return {"token": token, "user": _public_user(row)}


def logout(token: str) -> None:
    with _lock:
        _sessions.pop(token, None)


def user_for_token(conn, token: str) -> Dict[str, Any]:
    """Resolve the logged-in user (fresh from the DB, so role changes apply immediately)."""
    with _lock:
        uid = _sessions.get(token or "")
    if uid is None:
        raise AuthError("Your session has expired. Please log in again.")
    row = conn.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if row is None:
        raise AuthError("Your session has expired. Please log in again.")
    return _public_user(row)


def current_user(token: str) -> Dict[str, Any]:
    with db() as conn:
        return user_for_token(conn, token)
