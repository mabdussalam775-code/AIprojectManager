"""Validation of an AI draft BEFORE anything is saved. Complexity O(P + T + U): one pass over the
draft plus O(1) dictionary lookups into the user directory."""
from __future__ import annotations

import re
from datetime import date
from typing import Any, Dict, Iterable, List, Optional, Tuple

_ISO = re.compile(r"^\d{4}-\d{2}-\d{2}$")
MAX_HOURS = 1000


def parse_date(value: Any) -> Optional[date]:
    """Strict YYYY-MM-DD only."""
    if not isinstance(value, str):
        return None
    s = value.strip()
    if not _ISO.match(s):
        return None
    try:
        return date(int(s[:4]), int(s[5:7]), int(s[8:10]))
    except ValueError:
        return None


class Directory:
    """O(1) lookup of existing users by id / e-mail / full name / unique first name."""

    def __init__(self, users: Iterable[Dict[str, Any]]):
        self.users = list(users)
        self.by_id = {u["id"].upper(): u for u in self.users}
        self.by_email = {u.get("email", "").lower(): u for u in self.users if u.get("email")}
        self.by_name = {u["name"].lower(): u for u in self.users}
        self.by_first: Dict[str, List[Dict[str, Any]]] = {}
        for u in self.users:
            self.by_first.setdefault(u["name"].split()[0].lower(), []).append(u)

    def resolve(self, value: Any, role: str) -> Optional[Dict[str, Any]]:
        if not isinstance(value, str) or not value.strip():
            return None
        v = value.strip()
        for table, key in ((self.by_id, v.upper()), (self.by_email, v.lower()), (self.by_name, v.lower())):
            if key in table:
                return table[key]
        cands = self.by_first.get(v.split()[0].lower(), [])
        same_role = [u for u in cands if u["role"] == role]
        if len(same_role) == 1:
            return same_role[0]
        if len(cands) == 1:
            return cands[0]
        return None


def _text(d: Dict[str, Any], key: str) -> str:
    v = d.get(key)
    return v.strip() if isinstance(v, str) else ""


def validate_draft(draft: Any, users: Iterable[Dict[str, Any]],
                   existing_keys: Iterable[Tuple[str, str]] = ()) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    """Return (normalised_draft, issues). issues == [] means the draft is safe to save.
    The normalised draft always comes back (best effort) so the admin can correct it and revalidate."""
    issues: List[Dict[str, str]] = []

    def add(path: str, msg: str) -> None:
        issues.append({"path": path, "message": msg})

    directory = Directory(users)
    existing = {(n.lower(), c.lower()) for n, c in existing_keys}

    if not isinstance(draft, dict) or not isinstance(draft.get("projects"), list):
        add("projects", "The AI output must be an object with a 'projects' list.")
        return {"projects": []}, issues
    if not draft["projects"]:
        add("projects", "No projects were found in the transcript.")

    out_projects: List[Dict[str, Any]] = []
    seen = set()
    for i, p in enumerate(draft["projects"]):
        base = "projects[{}]".format(i)
        if not isinstance(p, dict):
            add(base, "Each project must be an object.")
            continue
        name, client = _text(p, "name"), _text(p, "clientName")
        label = "Project '{}'".format(name) if name else "Project #{}".format(i + 1)
        if not name:
            add(base + ".name", "{}: project name is required.".format(label))
        if not client:
            add(base + ".clientName", "{}: client name is required.".format(label))
        if name and client:
            key = (name.lower(), client.lower())
            if key in seen:
                add(base + ".name", "{}: appears twice in this draft.".format(label))
            elif key in existing:
                add(base + ".name", "{}: a project with this name and client already exists "
                                    "- rename it in the draft, or use CLEAR ALL on the dashboard first.".format(label))
            seen.add(key)

        # manager
        m_raw = p.get("managerId")
        manager = directory.resolve(m_raw, "MANAGER")
        if m_raw in (None, ""):
            add(base + ".managerId", "{}: manager is missing - please choose an existing manager id.".format(label))
        elif manager is None:
            add(base + ".managerId", "{}: manager '{}' is not in the team directory.".format(label, m_raw))
        elif manager["role"] != "MANAGER":
            add(base + ".managerId", "{}: '{}' is not a MANAGER.".format(label, manager["name"]))

        # deadline
        p_deadline_raw = p.get("deadline")
        p_deadline = parse_date(p_deadline_raw)
        if p_deadline is None:
            add(base + ".deadline", "{}: deadline '{}' is missing or not a valid YYYY-MM-DD date.".format(
                label, p_deadline_raw if p_deadline_raw not in (None, "") else "(empty)"))

        out_tasks: List[Dict[str, Any]] = []
        tasks = p.get("tasks")
        if not isinstance(tasks, list):
            add(base + ".tasks", "{}: 'tasks' must be a list.".format(label))
            tasks = []
        titles = set()
        for j, t in enumerate(tasks):
            tpath = "{}.tasks[{}]".format(base, j)
            if not isinstance(t, dict):
                add(tpath, "{}: each task must be an object.".format(label))
                continue
            title = _text(t, "title")
            tlabel = "{} / task '{}'".format(label, title) if title else "{} / task #{}".format(label, j + 1)
            if not title:
                add(tpath + ".title", "{}: task title is required.".format(tlabel))
            elif title.lower() in titles:
                add(tpath + ".title", "{}: duplicate task title in this project.".format(tlabel))
            titles.add(title.lower())

            a_raw = t.get("assigneeId")
            agent = directory.resolve(a_raw, "AGENT")
            if a_raw in (None, ""):
                add(tpath + ".assigneeId", "{}: assignee is missing - please choose an existing agent id.".format(tlabel))
            elif agent is None:
                add(tpath + ".assigneeId", "{}: assignee '{}' is not an existing team member.".format(tlabel, a_raw))
            elif agent["role"] != "AGENT":
                add(tpath + ".assigneeId", "{}: '{}' is not an AGENT.".format(tlabel, agent["name"]))

            hours_raw = t.get("estimatedHours")
            hours: Any = hours_raw
            try:
                if isinstance(hours_raw, bool):
                    raise ValueError
                hours = float(hours_raw)
                if not (0 < hours <= MAX_HOURS):
                    raise ValueError
            except (TypeError, ValueError):
                add(tpath + ".estimatedHours", "{}: estimated hours must be a positive number "
                                               "(got '{}').".format(tlabel, hours_raw))
                hours = hours_raw
            else:
                hours = int(hours) if hours == int(hours) else round(hours, 2)

            t_deadline_raw = t.get("deadline")
            t_deadline = parse_date(t_deadline_raw)
            if t_deadline is None:
                add(tpath + ".deadline", "{}: deadline '{}' is missing or not a valid YYYY-MM-DD date.".format(
                    tlabel, t_deadline_raw if t_deadline_raw not in (None, "") else "(empty)"))
            elif p_deadline is not None and t_deadline > p_deadline:
                add(tpath + ".deadline", "{}: task deadline {} is after the project deadline {}.".format(
                    tlabel, t_deadline.isoformat(), p_deadline.isoformat()))

            out_tasks.append({
                "title": title, "description": _text(t, "description")[:2000],
                "assigneeId": agent["id"] if agent else a_raw,
                "deadline": t_deadline.isoformat() if t_deadline else t_deadline_raw,
                "estimatedHours": hours,
            })

        out_projects.append({
            "name": name, "clientName": client, "description": _text(p, "description")[:4000],
            "managerId": manager["id"] if manager else m_raw,
            "deadline": p_deadline.isoformat() if p_deadline else p_deadline_raw,
            "tasks": out_tasks,
        })
    return {"projects": out_projects}, issues
