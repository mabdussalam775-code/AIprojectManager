"""Offline fallback extractor (used only when no AI key is configured, or AI_MODE=local).

It is a real parser, not a canned answer: it reads the transcript you give it, finds the project
headers and "<Person> owns <Task>: <N> hours, <D Month>" statements, lets the LAST statement win,
resolves people through the live team directory and builds the same JSON shape as the LLM.
It understands the *final recap* style of the supplied meeting. For free-form transcripts use the
LLM engine (set AI_API_KEY)."""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

_MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}

_HEADER = re.compile(
    r":\s*([A-Z][A-Za-z0-9&' \-]+?),\s*client\s+([^,]+?),\s*manager\s+([A-Za-z ]+?),\s*"
    r"deadline\s+(\d{1,2})\s+([A-Za-z]+)(?:\s+(20\d{2}))?\s*\.?")
_TASK = re.compile(
    r"\b([A-Z][a-z]+)\s+owns\s+([^:.]{2,80}?):\s*(\d+(?:\.\d+)?)\s*(?:estimated\s+)?hours?,\s*"
    r"(\d{1,2})\s+([A-Za-z]+)(?:\s+(20\d{2}))?")
_SPEAKER = re.compile(r"^[A-Z][a-z]+:\s*")
_SLOT = re.compile(r"^\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}\s*\|")
_TASK_CUE = re.compile(r"\b(covers?|includes?|scope|i will|i'll|selects?|should prepare|will connect)\b", re.I)
_NO_NUMBERS = re.compile(r"\b(hours?|estimate|estimated|due|own|owner)\b", re.I)


class ExtractionError(Exception):
    pass


def _iso(day: str, month: str, year: Optional[str], default_year: int) -> str:
    m = _MONTHS.get(month.lower()[:3])
    if not m:
        return "{} {}".format(day, month)          # left raw -> validator asks for a correction
    return "{:04d}-{:02d}-{:02d}".format(int(year or default_year), m, int(day))


def _person(name: str, role: str, users: List[Dict[str, Any]]) -> str:
    first = name.strip().split()[0].lower()
    hits = [u for u in users if u["name"].split()[0].lower() == first and u["role"] == role]
    return hits[0]["id"] if len(hits) == 1 else name.strip()   # unresolved -> raw name -> correction


def _sentences(text: str) -> List[str]:
    return [_SPEAKER.sub("", s).strip() for s in re.split(r"(?<=[.?!])\s+", text) if s.strip()]


def _tidy(sentence: str) -> str:
    """Turn first-person meeting speech into a neutral task description."""
    s = sentence.strip()
    m = re.match(r"^(?:That|It)\s+(covers?|includes?)\b(.*)$", s, re.I)
    if m:
        verb = m.group(1).lower()
        return (verb if verb.endswith("s") else verb + "s").capitalize() + m.group(2)
    m = re.match(r"^It\s+should\s+(\w+)\b(.*)$", s, re.I)
    if m:
        return m.group(1).capitalize() + m.group(2)
    m = re.match(r"^I(?:'ll|\s+will)\s+(\w+)\b(.*)$", s, re.I)
    if m:
        v = m.group(1).lower()
        v = v + ("es" if v.endswith(("s", "sh", "ch", "x")) else "s")
        return v.capitalize() + m.group(2)
    return s


def _task_description(sents: List[str], title: str, fallback: str) -> str:
    t = title.lower()
    for i, s in enumerate(sents):
        if t in s.lower():
            for cand in sents[i + 1:i + 4]:
                if _TASK_CUE.search(cand) and not _NO_NUMBERS.search(cand) and not cand.endswith("?"):
                    return _tidy(cand)
            break
    return fallback


def _project_description(sents: List[str], name: str, client: str) -> str:
    out = []
    for i, s in enumerate(sents):
        if name.lower() in s.lower():
            for cand in sents[i + 1:i + 5]:
                if re.search(r"\b(need|needs|want|wants)\b", cand, re.I) and not cand.endswith("?"):
                    out.append(cand)
                    break
            for cand in sents[i + 1:i + 14]:
                if re.search(r"\b(not included)\b|^This version is\b", cand, re.I):
                    out.append(cand)
                    break
            break
    return " ".join(out) if out else "{} delivery for {}.".format(name, client)


def extract(transcript: str, directory: List[Dict[str, Any]], default_year: int = 2026) -> Dict[str, Any]:
    lines = [ln.strip() for ln in transcript.splitlines()
             if ln.strip() and "INFINITY HACK" not in ln and not _SLOT.match(ln.strip())]
    flat = re.sub(r"\s+", " ", " ".join(lines))
    year_hit = re.search(r"\b(20\d{2})\b", transcript)
    year = int(year_hit.group(1)) if year_hit else default_year

    headers = list(_HEADER.finditer(flat))
    if not headers:
        raise ExtractionError(
            "The local extractor could not find a final recap such as "
            "'<Project>, client <Client>, manager <Name>, deadline <D Month>.' "
            "Configure AI_API_KEY to enable the full AI engine for free-form transcripts.")

    projects: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []
    positions = []
    for h in headers:
        name = h.group(1).strip()
        if name not in projects:
            order.append(name)
            projects[name] = {"tasks": {}}
        projects[name].update(
            name=name, clientName=h.group(2).strip(), managerId=_person(h.group(3), "MANAGER", directory),
            deadline=_iso(h.group(4), h.group(5), h.group(6), year))
        positions.append((h.start(), name))

    before_recap = _sentences(flat[:headers[0].start()])
    for m in _TASK.finditer(flat):
        owner = [n for pos, n in positions if pos < m.start()]
        if not owner:
            continue                                   # statement before any project header
        title = m.group(2).strip()
        hours = float(m.group(3))
        projects[owner[-1]]["tasks"][title.lower()] = {   # last statement wins
            "title": title,
            "assigneeId": _person(m.group(1), "AGENT", directory),
            "deadline": _iso(m.group(4), m.group(5), m.group(6), year),
            "estimatedHours": int(hours) if hours == int(hours) else hours,
        }
    if not any(p["tasks"] for p in projects.values()):
        raise ExtractionError("No '<Person> owns <Task>: <N> hours, <D Month>' statements were found.")

    result: List[Dict[str, Any]] = []
    for name in order:
        p = projects[name]
        tasks = []
        for t in p["tasks"].values():
            t["description"] = _task_description(
                before_recap, t["title"], "{} for {} ({}).".format(t["title"], name, p["clientName"]))
            tasks.append(t)
        result.append({
            "name": name, "clientName": p["clientName"],
            "description": _project_description(before_recap, name, p["clientName"]),
            "managerId": p["managerId"], "deadline": p["deadline"], "tasks": tasks})
    return {"projects": result}
