from __future__ import annotations

import traceback
from tkinter import messagebox

import customtkinter as ctk

from .. import access, auth, seed
from ..database import init_db
from . import theme as T
from .detail_view import ProjectDetailView
from .login_view import LoginView
from .projects_view import ProjectsView
from .tasks_view import MyTasksView
from .team_view import TeamView
from .transcript_view import TranscriptView
from .widgets import badge, ghost_button, label

NAV = {
    "ADMIN":   [("▣  Dashboard", "projects"), ("⚡  Create from Transcript", "transcript"), ("☰  Team Directory", "team")],
    "MANAGER": [("▣  My Projects", "projects"), ("☰  Team Directory", "team")],
    "AGENT":   [("✔  My Tasks", "mytasks"), ("▣  My Projects", "projects"), ("☰  Team Directory", "team")],
}
HOME = {"ADMIN": "projects", "MANAGER": "projects", "AGENT": "mytasks"}


class Shell(ctk.CTkFrame):
    """Sidebar + content area shown after login."""

    def __init__(self, master, app):
        super().__init__(master, fg_color=T.BG)
        self.app, self.view, self.nav_buttons = app, None, {}
        user = app.user
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        side = ctk.CTkFrame(self, width=250, fg_color=T.PANEL, corner_radius=0)
        side.grid(row=0, column=0, sticky="ns")
        side.pack_propagate(False)
        label(side, "◢ NOVAWORKS", 22, T.CYAN, "bold", True).pack(anchor="w", padx=22, pady=(26, 0))
        label(side, "AI PROJECT MANAGER", 10, T.MAGENTA, "bold", True).pack(anchor="w", padx=24, pady=(0, 26))
        for text, key in NAV[user["role"]]:
            b = ctk.CTkButton(side, text=text, anchor="w", height=42, corner_radius=8, fg_color="transparent",
                              hover_color=T.CARD, text_color=T.MUTED, font=T.font(13, "bold"),
                              command=lambda k=key: self.navigate(k))
            b.pack(fill="x", padx=14, pady=3)
            self.nav_buttons[key] = b

        chip = ctk.CTkFrame(side, fg_color=T.CARD, border_width=1, border_color=T.BORDER, corner_radius=12)
        chip.pack(side="bottom", fill="x", padx=14, pady=16)
        label(chip, user["name"], 14, T.TEXT, "bold", anchor="w").pack(anchor="w", padx=14, pady=(12, 2))
        badge(chip, T.ROLE_LABEL[user["role"]], T.ROLE_COLOR[user["role"]]).pack(anchor="w", padx=12)
        label(chip, user["email"], 10, T.MUTED, mono=True, anchor="w").pack(anchor="w", padx=14, pady=(6, 8))
        ghost_button(chip, "LOGOUT", app.logout, color=T.RED, height=32).pack(fill="x", padx=12, pady=(0, 12))

        self.content = ctk.CTkFrame(self, fg_color=T.BG, corner_radius=0)
        self.content.grid(row=0, column=1, sticky="nsew")
        self.navigate(HOME[user["role"]])

    def navigate(self, key: str, **kw) -> None:
        role = self.app.user["role"]
        if key == "transcript" and role != "ADMIN":          # UI guard; the data layer enforces it too
            return
        if self.view is not None:
            self.view.destroy()
        views = {"projects": ProjectsView, "mytasks": MyTasksView, "team": TeamView,
                 "transcript": TranscriptView, "project": ProjectDetailView}
        self.view = views[key](self.content, self.app, self, **kw)
        self.view.pack(fill="both", expand=True)
        active = kw.get("back", "projects") if key == "project" else key
        for k, b in self.nav_buttons.items():
            on = (k == active)
            b.configure(fg_color=T.CARD if on else "transparent", text_color=T.CYAN if on else T.MUTED)


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("NovaWorks CRM  //  AI Project Manager")
        self.geometry("720x500")
        self.minsize(1120, 700)
        self.configure(fg_color=T.BG)
        self.token = None
        self.user = None
        self.frame = None
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.show_login()

    # -- screen switching
    def _swap(self, frame) -> None:
        if self.frame is not None:
            self.frame.destroy()
        self.frame = frame
        frame.pack(fill="both", expand=True)

    def show_login(self, notice: str = "") -> None:
        self._swap(LoginView(self, self.on_login, notice))

    def on_login(self, token: str, user: dict) -> None:
        self.token, self.user = token, user
        self._swap(Shell(self, self))

    def logout(self) -> None:
        if self.token:
            auth.logout(self.token)
        self.token = self.user = None
        self.show_login()

    def force_logout(self, message: str) -> None:
        self.token = self.user = None
        self.after(0, lambda: self.show_login(message))

    def on_close(self) -> None:
        if self.token:
            auth.logout(self.token)
        self.destroy()

    # -- data-call helper: passes the session token, turns errors into friendly dialogs
    def call(self, fn, *args, **kw):
        try:
            return fn(self.token, *args, **kw)
        except auth.AuthError as exc:
            self.force_logout(str(exc))
        except access.AccessDenied as exc:
            messagebox.showwarning("Access denied", str(exc))
        except Exception as exc:
            messagebox.showerror("Error", "{}: {}".format(type(exc).__name__, exc))
        return None

    def report_callback_exception(self, exc, val, tb) -> None:
        traceback.print_exception(exc, val, tb)
        messagebox.showerror("Unexpected error", "{}: {}".format(exc.__name__, val))


def run() -> None:
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("dark-blue")
    init_db()
    seed.seed_demo_users()          # idempotent: creates the ten demo accounts on first launch
    App().mainloop()
