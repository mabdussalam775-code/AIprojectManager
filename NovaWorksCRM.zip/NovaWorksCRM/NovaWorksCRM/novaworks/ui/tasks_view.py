from __future__ import annotations

import customtkinter as ctk

from .. import access
from . import theme as T
from .widgets import Table, fmt_date, fmt_hours, label, page_header, stat_row


class MyTasksView(ctk.CTkScrollableFrame):
    """Agent screen: only tasks assigned to the logged-in developer."""

    def __init__(self, master, app, shell):
        super().__init__(master, fg_color="transparent")
        page_header(self, "MY TASKS", "Only tasks assigned to you. Click a row to open its project.").pack(
            anchor="w", padx=16, pady=(22, 10))
        tasks = app.call(access.get_my_tasks) or []
        stat_row(self, [("MY TASKS", str(len(tasks)), T.GREEN),
                        ("PROJECTS", str(len({t["project_id"] for t in tasks})), T.CYAN),
                        ("EST. HOURS", "{:g}".format(sum(t["estimated_hours"] for t in tasks)), T.MAGENTA)]
                 ).pack(fill="x", padx=16, pady=(0, 12))
        table = Table(self, [("title", "Task", 2.0, 190), ("project_name", "Project", 1.8, 170),
                             ("description", "Description", 3.6, 330), ("deadline_fmt", "Deadline", 1.2, 100),
                             ("hours_fmt", "Est. hours", 1.0, 80)])
        rows = [dict(t, deadline_fmt=fmt_date(t["deadline"]), hours_fmt=fmt_hours(t["estimated_hours"])) for t in tasks]
        table.set_rows(rows, colors={"project_name": lambda r: T.CYAN, "deadline_fmt": lambda r: T.AMBER,
                                     "hours_fmt": lambda r: T.MAGENTA},
                       on_click=lambda r: shell.navigate("project", project_id=r["project_id"], back="mytasks"),
                       empty="No tasks have been assigned to you yet.")
        table.pack(fill="x", padx=16, pady=(0, 20))
