"""Reusable themed widgets and formatting helpers."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import customtkinter as ctk

from . import theme as T


def fmt_date(iso: str) -> str:
    try:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d %b %Y")
    except (TypeError, ValueError):
        return str(iso)


def fmt_hours(h: Any) -> str:
    try:
        h = float(h)
    except (TypeError, ValueError):
        return str(h)
    return "{:g} h".format(h)


def label(master, text: str, size: int = 13, color: str = T.TEXT, weight: str = "normal",
          mono: bool = False, **kw) -> ctk.CTkLabel:
    return ctk.CTkLabel(master, text=text, text_color=color, font=T.font(size, weight, mono), **kw)


def primary_button(master, text: str, command: Callable, **kw) -> ctk.CTkButton:
    kw.setdefault("height", 38)
    return ctk.CTkButton(master, text=text, command=command, fg_color=T.CYAN, hover_color=T.CYAN_DIM,
                         text_color=T.DARK_TEXT, font=T.font(13, "bold"), corner_radius=8, **kw)


def ghost_button(master, text: str, command: Callable, color: str = T.CYAN, **kw) -> ctk.CTkButton:
    kw.setdefault("height", 36)
    return ctk.CTkButton(master, text=text, command=command, fg_color="transparent", hover_color=T.CARD,
                         text_color=color, border_width=1, border_color=color, font=T.font(13, "bold"),
                         corner_radius=8, **kw)


def danger_button(master, text: str, command: Callable, **kw) -> ctk.CTkButton:
    return ghost_button(master, text, command, color=T.RED, **kw)


def badge(master, text: str, color: str) -> ctk.CTkLabel:
    return ctk.CTkLabel(master, text="  {}  ".format(text), text_color=color, fg_color=T.BG,
                        font=T.font(10, "bold", True), corner_radius=6)


def page_header(master, title: str, subtitle: str = "") -> ctk.CTkFrame:
    f = ctk.CTkFrame(master, fg_color="transparent")
    label(f, title, 24, T.CYAN, "bold", True).pack(anchor="w")
    if subtitle:
        label(f, subtitle, 12, T.MUTED).pack(anchor="w", pady=(2, 0))
    return f


class StatTile(ctk.CTkFrame):
    def __init__(self, master, caption: str, value: str, accent: str = T.CYAN):
        super().__init__(master, fg_color=T.CARD, border_width=1, border_color=T.BORDER, corner_radius=12)
        label(self, value, 26, accent, "bold", True).pack(anchor="w", padx=16, pady=(12, 0))
        label(self, caption, 10, T.MUTED, "bold", True).pack(anchor="w", padx=16, pady=(0, 12))


def stat_row(master, tiles: Sequence[Tuple[str, str, str]]) -> ctk.CTkFrame:
    row = ctk.CTkFrame(master, fg_color="transparent")
    for i, (caption, value, accent) in enumerate(tiles):
        row.grid_columnconfigure(i, weight=1, uniform="stat")
        StatTile(row, caption, value, accent).grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 8, 0))
    return row


def bind_click(widget, callback: Callable[[], None]) -> None:
    """Make a whole composite widget (and all its children) clickable."""
    try:
        widget.bind("<Button-1>", lambda _e: callback(), add="+")
        widget.configure(cursor="hand2")
    except Exception:
        pass
    for child in widget.winfo_children():
        bind_click(child, callback)


class Table(ctk.CTkFrame):
    """Simple themed table. columns = [(key, header, weight, wraplength)]."""

    def __init__(self, master, columns: List[Tuple[str, str, float, int]]):
        super().__init__(master, fg_color=T.CARD_ALT, border_width=1, border_color=T.BORDER, corner_radius=12)
        self.columns = columns
        head = ctk.CTkFrame(self, fg_color=T.PANEL, corner_radius=10)
        head.pack(fill="x", padx=2, pady=2)
        self._grid_cols(head)
        for i, (_k, title, _w, _wrap) in enumerate(columns):
            label(head, title.upper(), 10, T.CYAN, "bold", True, anchor="w").grid(
                row=0, column=i, sticky="w", padx=12, pady=9)
        self.body = ctk.CTkFrame(self, fg_color="transparent")
        self.body.pack(fill="x", padx=2, pady=(0, 2))

    def _grid_cols(self, frame) -> None:
        for i, (_k, _t, weight, _wrap) in enumerate(self.columns):
            frame.grid_columnconfigure(i, weight=int(weight * 10), uniform="tbl")

    def set_rows(self, rows: List[Dict[str, Any]], colors: Optional[Dict[str, Callable]] = None,
                 on_click: Optional[Callable[[Dict[str, Any]], None]] = None, empty: str = "Nothing to show.") -> None:
        for w in self.body.winfo_children():
            w.destroy()
        if not rows:
            label(self.body, empty, 13, T.MUTED).pack(pady=24)
            return
        colors = colors or {}
        for n, row in enumerate(rows):
            line = ctk.CTkFrame(self.body, fg_color=T.CARD if n % 2 == 0 else "transparent", corner_radius=8)
            line.pack(fill="x")
            self._grid_cols(line)
            for i, (key, _t, _w, wrap) in enumerate(self.columns):
                color = colors[key](row) if key in colors else T.TEXT
                label(line, str(row.get(key, "")), 12, color, anchor="w", justify="left",
                      wraplength=wrap).grid(row=0, column=i, sticky="w", padx=12, pady=9)
            if on_click:
                bind_click(line, lambda r=row: on_click(r))
