from __future__ import annotations

import customtkinter as ctk

from .. import access
from . import theme as T
from .widgets import Table, badge, fmt_date, fmt_hours, ghost_button, label, stat_row


class ProjectDetailView(ctk.CTkScrollableFrame):
    def __init__(self, master, app, shell, project_id, back="projects"):
        super().__init__(master, fg_color="transparent")
        self.app, self.shell = app, shell
        project = app.call(access.get_project_by_id, project_id)
        if project is None:                         # denied or error -> go back
            self.after(10, lambda: shell.navigate(back))
            return

        top = ctk.CTkFrame(self, fg_color="transparent"); top.pack(fill="x", padx=12, pady=(14, 6))
        ghost_button(top, "◂ BACK", lambda: shell.navigate(back), width=90).pack(side="left")

        head = ctk.CTkFrame(self, fg_color=T.CARD, border_width=1, border_color=T.BORDER, corner_radius=14)
        head.pack(fill="x", padx=12, pady=8)
        inner = ctk.CTkFrame(head, fg_color="transparent"); inner.pack(fill="x", padx=22, pady=18)
        label(inner, project["name"], 26, T.CYAN, "bold", anchor="w").pack(anchor="w")
        label(inner, "CLIENT  ·  " + project["client_name"], 12, T.MAGENTA, "bold", True).pack(anchor="w", pady=(2, 10))
        label(inner, project["description"] or "No description.", 13, T.TEXT, anchor="w",
              justify="left", wraplength=900).pack(anchor="w")

        stat_row(self, [("PROJECT MANAGER", project["manager_name"], T.CYAN),
                        ("DEADLINE", fmt_date(project["deadline"]), T.AMBER),
                        ("TASKS", str(len(project["tasks"])), T.GREEN),
                        ("EST. HOURS", "{:g}".format(sum(t["estimated_hours"] for t in project["tasks"])), T.MAGENTA)]
                 ).pack(fill="x", padx=12, pady=8)

        if project["scope"] == "own-tasks-only":
            badge(self, "ACCESS SCOPE: ONLY YOUR TASKS IN THIS PROJECT ARE SHOWN", T.AMBER).pack(anchor="w", padx=12, pady=(4, 0))

        label(self, "TASKS", 14, T.CYAN, "bold", True).pack(anchor="w", padx=14, pady=(14, 6))
        table = Table(self, [("title", "Task", 2.2, 200), ("description", "Description", 4.2, 380),
                             ("assignee_name", "Assigned agent", 1.6, 140), ("deadline_fmt", "Deadline", 1.3, 110),
                             ("hours_fmt", "Est. hours", 1.0, 80)])
        rows = [dict(t, deadline_fmt=fmt_date(t["deadline"]), hours_fmt=fmt_hours(t["estimated_hours"]))
                for t in project["tasks"]]
        table.set_rows(rows, colors={"title": lambda r: T.TEXT, "assignee_name": lambda r: T.GREEN,
                                     "deadline_fmt": lambda r: T.AMBER, "hours_fmt": lambda r: T.MAGENTA},
                       empty="No tasks to show.")
        table.pack(fill="x", padx=12, pady=(0, 20))
