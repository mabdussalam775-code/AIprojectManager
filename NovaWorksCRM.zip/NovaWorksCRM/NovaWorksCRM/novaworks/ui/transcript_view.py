"""Admin-only 'Create from Transcript' screen.

The AI call + validation + save run in a worker thread (UI stays responsive); the button is disabled
while processing so repeated clicks can never create duplicates."""
from __future__ import annotations

import json
import queue
import threading

import customtkinter as ctk

from .. import ai_service, auth, config, transcript_service
from ..access import AccessDenied
from . import theme as T
from .widgets import (badge, bind_click, ghost_button, label, page_header, primary_button)


class TranscriptView(ctk.CTkScrollableFrame):
    def __init__(self, master, app, shell):
        super().__init__(master, fg_color="transparent")
        self.app, self.shell = app, shell
        self._q: "queue.Queue" = queue.Queue()
        self._busy = False

        top = ctk.CTkFrame(self, fg_color="transparent"); top.pack(fill="x", padx=16, pady=(22, 8))
        page_header(top, "CREATE FROM TRANSCRIPT",
                    "Paste the meeting transcript. AI creates projects, tasks, owners, deadlines and hours.").pack(side="left")
        badge(top, "ENGINE: " + ai_service.engine_label().upper(),
              T.GREEN if ai_service.mode() == "llm" else T.AMBER).pack(side="right")

        self.box = ctk.CTkTextbox(self, height=300, wrap="word", font=T.font(12, mono=True), fg_color=T.CARD_ALT,
                                  border_width=1, border_color=T.BORDER, text_color=T.TEXT)
        self.box.pack(fill="x", padx=16, pady=(4, 10))

        bar = ctk.CTkFrame(self, fg_color="transparent"); bar.pack(fill="x", padx=16)
        self.btn_sample = ghost_button(bar, "LOAD SUPPLIED TRANSCRIPT", self.load_sample, width=220)
        self.btn_sample.pack(side="left")
        self.btn_clear = ghost_button(bar, "CLEAR", lambda: self.box.delete("1.0", "end"), color=T.MUTED, width=80)
        self.btn_clear.pack(side="left", padx=8)
        self.btn_create = primary_button(bar, "CREATE FROM TRANSCRIPT  ▸", self.start, width=260)
        self.btn_create.pack(side="right")

        status = ctk.CTkFrame(self, fg_color="transparent"); status.pack(fill="x", padx=16, pady=(12, 0))
        self.progress = ctk.CTkProgressBar(status, mode="indeterminate", progress_color=T.CYAN, fg_color=T.BORDER, height=6)
        self.status = label(status, "", 12, T.MUTED, mono=True)
        self.status.pack(anchor="w")

        self.result = ctk.CTkFrame(self, fg_color="transparent")
        self.result.pack(fill="x", padx=16, pady=14)

    # ------------------------------------------------------------------ helpers
    def _clear_result(self) -> None:
        for w in self.result.winfo_children():
            w.destroy()

    def _set_busy(self, busy: bool, text: str = "") -> None:
        self._busy = busy
        state = "disabled" if busy else "normal"
        for b in (self.btn_create, self.btn_sample, self.btn_clear):
            b.configure(state=state)
        self.btn_create.configure(text="PROCESSING…" if busy else "CREATE FROM TRANSCRIPT  ▸")
        if busy:
            self.progress.pack(fill="x", pady=(0, 6), before=self.status)
            self.progress.start()
        else:
            self.progress.stop()
            self.progress.pack_forget()
        self.status.configure(text=text, text_color=T.CYAN)

    def load_sample(self) -> None:
        path = config.BASE_DIR / "sample_transcript.txt"
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            self._show_error("sample_transcript.txt was not found next to main.py.")
            return
        self.box.delete("1.0", "end")
        self.box.insert("1.0", text)
        self.status.configure(text="Supplied transcript loaded ({} characters).".format(len(text)), text_color=T.MUTED)

    # ------------------------------------------------------------------ actions
    def start(self) -> None:
        if self._busy:
            return
        text = self.box.get("1.0", "end").strip()
        if not text:
            self._clear_result()
            self._show_error("The transcript is empty. Paste the meeting transcript first.")
            return
        self._run(transcript_service.create_from_transcript, text,
                  status="Analysing transcript with {} … this can take up to a minute.".format(
                      "the AI model" if ai_service.mode() == "llm" else "the local extractor"))

    def revalidate(self) -> None:
        if self._busy:
            return
        try:
            draft = json.loads(self.editor.get("1.0", "end"))
        except ValueError as exc:
            self.edit_msg.configure(text="That is not valid JSON: {}".format(exc), text_color=T.RED)
            return
        self._run(transcript_service.save_draft, draft, status="Re-validating corrected draft …")

    def _run(self, fn, payload, status: str) -> None:
        self._clear_result()
        self._set_busy(True, status)

        def work():
            try:
                self._q.put(("ok", fn(self.app.token, payload)))
            except Exception as exc:                      # shown to the user, never swallowed
                self._q.put(("err", exc))

        threading.Thread(target=work, daemon=True).start()
        self.after(120, self._poll)

    def _poll(self) -> None:
        if not self.winfo_exists():
            return
        try:
            kind, payload = self._q.get_nowait()
        except queue.Empty:
            self.after(120, self._poll)
            return
        self._set_busy(False)
        if kind == "ok":
            self.status.configure(text="")
            (self._show_success if payload["status"] == "created" else self._show_issues)(payload)
        elif isinstance(payload, auth.AuthError):
            self.app.force_logout(str(payload))
        elif isinstance(payload, (AccessDenied, transcript_service.TranscriptError, ai_service.AIError)):
            self._show_error(str(payload))
        else:
            self._show_error("Unexpected error ({}): {}".format(type(payload).__name__, payload))

    # ------------------------------------------------------------------ results
    def _panel(self, color: str) -> ctk.CTkFrame:
        p = ctk.CTkFrame(self.result, fg_color=T.CARD, border_width=1, border_color=color, corner_radius=14)
        p.pack(fill="x")
        inner = ctk.CTkFrame(p, fg_color="transparent"); inner.pack(fill="x", padx=20, pady=16)
        return inner

    def _show_error(self, message: str) -> None:
        self._clear_result()
        inner = self._panel(T.RED)
        label(inner, "✖ COULD NOT CREATE PROJECTS  -  nothing was saved", 14, T.RED, "bold", True).pack(anchor="w")
        label(inner, message, 13, T.TEXT, anchor="w", justify="left", wraplength=860).pack(anchor="w", pady=(8, 0))

    def _show_success(self, res) -> None:
        self._clear_result()
        inner = self._panel(T.GREEN)
        label(inner, "✔ SUCCESS  -  {} projects and {} tasks created ({:g} est. hours)".format(
            res["project_count"], res["task_count"], res["total_hours"]), 15, T.GREEN, "bold", True).pack(anchor="w")
        label(inner, "Engine: {}   ·   All records were saved in one transaction.".format(res["engine"]),
              11, T.MUTED, mono=True).pack(anchor="w", pady=(2, 10))
        for p in res["projects"]:
            row = ctk.CTkFrame(inner, fg_color=T.CARD_ALT, corner_radius=8); row.pack(fill="x", pady=3)
            label(row, p["name"], 13, T.CYAN, "bold").pack(side="left", padx=14, pady=9)
            label(row, "{} tasks  ·  {:g} h   ▸".format(p["task_count"], p["total_hours"]), 12, T.MUTED).pack(side="right", padx=14)
            bind_click(row, lambda pid=p["id"]: self.shell.navigate("project", project_id=pid, back="projects"))
        primary_button(inner, "VIEW ALL PROJECTS  ▸", lambda: self.shell.navigate("projects"), width=230).pack(anchor="w", pady=(12, 0))

    def _show_issues(self, res) -> None:
        self._clear_result()
        inner = self._panel(T.AMBER)
        label(inner, "⚠ CORRECTION NEEDED  -  nothing was saved", 15, T.AMBER, "bold", True).pack(anchor="w")
        label(inner, "{} problem(s) found by {}. Fix them in the draft below and press REVALIDATE & SAVE.".format(
            len(res["issues"]), res["engine"]), 12, T.MUTED).pack(anchor="w", pady=(2, 10))
        for issue in res["issues"]:
            line = ctk.CTkFrame(inner, fg_color=T.CARD_ALT, corner_radius=8); line.pack(fill="x", pady=2)
            label(line, "•  " + issue["message"], 12, T.TEXT, anchor="w", justify="left", wraplength=840).pack(
                anchor="w", padx=12, pady=(7, 0))
            label(line, issue["path"], 10, T.MUTED, mono=True).pack(anchor="w", padx=26, pady=(0, 7))
        label(inner, "DRAFT (editable JSON)", 11, T.CYAN, "bold", True).pack(anchor="w", pady=(14, 4))
        self.editor = ctk.CTkTextbox(inner, height=320, wrap="none", font=T.font(11, mono=True), fg_color=T.BG,
                                     border_width=1, border_color=T.BORDER, text_color=T.TEXT)
        self.editor.pack(fill="x")
        self.editor.insert("1.0", json.dumps(res["draft"], indent=2, ensure_ascii=False))
        row = ctk.CTkFrame(inner, fg_color="transparent"); row.pack(fill="x", pady=(10, 0))
        primary_button(row, "REVALIDATE & SAVE  ▸", self.revalidate, width=230).pack(side="left")
        self.edit_msg = label(row, "", 12, T.RED, wraplength=520, justify="left")
        self.edit_msg.pack(side="left", padx=14)
