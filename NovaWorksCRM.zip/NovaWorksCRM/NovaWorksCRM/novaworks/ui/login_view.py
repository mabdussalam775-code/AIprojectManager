from __future__ import annotations

import customtkinter as ctk

from .. import auth, seed
from . import theme as T
from .widgets import label, primary_button


class LoginView(ctk.CTkFrame):
    def __init__(self, master, on_success, notice: str = ""):
        super().__init__(master, fg_color=T.BG)
        self.on_success = on_success

        card = ctk.CTkFrame(self, fg_color=T.CARD, border_width=1, border_color=T.CYAN_DIM,
                            corner_radius=18, width=440)
        card.place(relx=0.5, rely=0.5, anchor="center")
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(padx=40, pady=34)

        label(inner, "◢ NOVAWORKS", 30, T.CYAN, "bold", True).pack(anchor="w")
        label(inner, "AI PROJECT MANAGER  //  CRM", 12, T.MAGENTA, "bold", True).pack(anchor="w", pady=(0, 6))
        label(inner, "Sign in to continue. Access is limited to your role.", 12, T.MUTED).pack(anchor="w", pady=(0, 18))

        label(inner, "EMAIL", 10, T.MUTED, "bold", True).pack(anchor="w")
        self.email = ctk.CTkEntry(inner, width=360, height=40, fg_color=T.BG, border_color=T.BORDER,
                                  text_color=T.TEXT, placeholder_text="name@novaworks.example")
        self.email.pack(pady=(2, 12))
        label(inner, "PASSWORD", 10, T.MUTED, "bold", True).pack(anchor="w")
        self.password = ctk.CTkEntry(inner, width=360, height=40, show="•", fg_color=T.BG,
                                     border_color=T.BORDER, text_color=T.TEXT, placeholder_text="••••••••")
        self.password.pack(pady=(2, 8))

        self.msg = label(inner, notice, 12, T.AMBER if notice else T.RED, wraplength=360, justify="left")
        self.msg.pack(anchor="w", pady=(0, 6))

        self.btn = primary_button(inner, "LOGIN  ▸", self.submit, width=360)
        self.btn.pack(pady=(2, 14))

        label(inner, "DEMO ACCOUNTS  (password: Demo123!)", 10, T.MUTED, "bold", True).pack(anchor="w")
        options = ["{} — {}".format(a[1], a[2]) for a in seed.DEMO_ACCOUNTS]
        self.picker = ctk.CTkOptionMenu(inner, values=options, width=360, command=self.fill,
                                        fg_color=T.BG, button_color=T.BORDER, button_hover_color=T.CYAN_DIM,
                                        text_color=T.TEXT, dropdown_fg_color=T.PANEL, dropdown_text_color=T.TEXT)
        self.picker.set("Quick-fill a demo account…")
        self.picker.pack(pady=(4, 0))

        for w in (self.email, self.password):
            w.bind("<Return>", lambda _e: self.submit())
        self.email.focus_set()

    def fill(self, choice: str) -> None:
        email = choice.split("—")[-1].strip()
        self.email.delete(0, "end"); self.email.insert(0, email)
        self.password.delete(0, "end"); self.password.insert(0, "Demo123!")
        self.msg.configure(text="")

    def submit(self) -> None:
        try:
            result = auth.login(self.email.get(), self.password.get())
        except auth.AuthError as exc:
            self.msg.configure(text=str(exc), text_color=T.RED)
            self.password.delete(0, "end")
            return
        self.on_success(result["token"], result["user"])
