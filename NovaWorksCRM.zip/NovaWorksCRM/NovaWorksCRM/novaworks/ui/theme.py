"""Dark / cyberpunk design tokens."""
from __future__ import annotations

import customtkinter as ctk

BG = "#060a14"
PANEL = "#0b1222"
CARD = "#101a2e"
CARD_ALT = "#0d1527"
BORDER = "#1c2b4a"
CYAN = "#00e5ff"
CYAN_DIM = "#00a8bd"
MAGENTA = "#ff2bd6"
GREEN = "#39ff88"
AMBER = "#ffb800"
RED = "#ff3860"
TEXT = "#e6f1ff"
MUTED = "#7f93b5"
DARK_TEXT = "#04101a"

ROLE_COLOR = {"ADMIN": MAGENTA, "MANAGER": CYAN, "AGENT": GREEN}
ROLE_LABEL = {"ADMIN": "ADMIN", "MANAGER": "MANAGER", "AGENT": "DEVELOPER"}

FONT_UI = "Segoe UI"
FONT_MONO = "Consolas"


def font(size: int = 13, weight: str = "normal", mono: bool = False) -> ctk.CTkFont:
    return ctk.CTkFont(family=FONT_MONO if mono else FONT_UI, size=size, weight=weight)
