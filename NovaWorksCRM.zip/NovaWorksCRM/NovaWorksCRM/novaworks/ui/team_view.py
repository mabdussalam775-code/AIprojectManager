from __future__ import annotations

import customtkinter as ctk

from .. import access
from . import theme as T
from .widgets import Table, label, page_header


class TeamView(ctk.CTkScrollableFrame):
    """Read-only team directory (names, roles, specializations). Visible to every logged-in user."""

    def __init__(self, master, app, shell):
        super().__init__(master, fg_color="transparent")
        page_header(self, "TEAM DIRECTORY", "NovaWorks Technologies  ·  read-only").pack(anchor="w", padx=16, pady=(22, 12))
        team = app.call(access.get_team_directory) or []
        rows = [dict(m, role_label=T.ROLE_LABEL[m["role"]], skills_text=", ".join(m["skills"])) for m in team]
        table = Table(self, [("name", "Name", 2.0, 190), ("role_label", "Role", 1.3, 120),
                             ("specialization", "Specialization", 2.4, 230), ("skills_text", "Skills", 3.2, 300)])
        table.set_rows(rows, colors={"name": lambda r: T.TEXT, "role_label": lambda r: T.ROLE_COLOR[r["role"]],
                                     "specialization": lambda r: T.TEXT, "skills_text": lambda r: T.MUTED})
        table.pack(fill="x", padx=16, pady=(0, 20))
        label(self, "{} members".format(len(team)), 11, T.MUTED, mono=True).pack(anchor="w", padx=18, pady=(0, 20))
