from __future__ import annotations

from tkinter import messagebox

import customtkinter as ctk

from .. import access
from . import theme as T
from .widgets import (badge, bind_click, danger_button, fmt_date, fmt_hours, ghost_button, label,
                      page_header, primary_button, stat_row)

CARD_W = 350


class ProjectCard(ctk.CTkFrame):
    def __init__(self, master, project, on_open):
        super().__init__(master, fg_color=T.CARD, border_width=1, border_color=T.BORDER, corner_radius=14)
        pad = ctk.CTkFrame(self, fg_color="transparent")
        pad.pack(fill="both", expand=True, padx=18, pady=16)

        label(pad, project["name"], 17, T.CYAN, "bold", anchor="w", justify="left", wraplength=265).pack(anchor="w")
        label(pad, "CLIENT  ·  " + project["client_name"], 11, T.MUTED, "bold", True, anchor="w").pack(anchor="w", pady=(2, 8))
        desc = project["description"] or "No description."
        label(pad, desc if len(desc) < 100 else desc[:97] + "…", 12, T.TEXT, anchor="w", justify="left",
              wraplength=265).pack(anchor="w", pady=(0, 10))

        ctk.CTkFrame(pad, height=1, fg_color=T.BORDER).pack(fill="x", pady=(0, 10))
        for cap, val, col in (("MANAGER", project["manager_name"], T.TEXT),
                              ("DEADLINE", fmt_date(project["deadline"]), T.AMBER)):
            r = ctk.CTkFrame(pad, fg_color="transparent"); r.pack(fill="x", pady=1)
            label(r, cap, 10, T.MUTED, "bold", True, width=80, anchor="w").pack(side="left")
            label(r, val, 12, col, "bold").pack(side="left")
        r = ctk.CTkFrame(pad, fg_color="transparent"); r.pack(fill="x", pady=(10, 0))
        badge(r, "{} TASKS".format(project["task_count"]), T.GREEN).pack(side="left")
        badge(r, fmt_hours(project["total_hours"]).upper(), T.MAGENTA).pack(side="left", padx=6)
        label(r, "OPEN  ▸", 11, T.CYAN, "bold", True).pack(side="right")

        bind_click(self, lambda: on_open(project["id"]))
        self.bind("<Enter>", lambda _e: self.configure(border_color=T.CYAN))
        self.bind("<Leave>", lambda _e: self.configure(border_color=T.BORDER))


class ProjectsView(ctk.CTkFrame):
    def __init__(self, master, app, shell):
        super().__init__(master, fg_color="transparent")
        self.app, self.shell = app, shell
        role = app.user["role"]
        title, sub = {
            "ADMIN": ("ALL PROJECTS", "Company overview - every project and its tasks."),
            "MANAGER": ("MY PROJECTS", "Projects assigned to you as manager."),
            "AGENT": ("MY PROJECTS", "Projects that contain tasks assigned to you."),
        }[role]

        top = ctk.CTkFrame(self, fg_color="transparent"); top.pack(fill="x", padx=28, pady=(24, 12))
        page_header(top, title, sub).pack(side="left")
        if role == "ADMIN":
            primary_button(top, "＋ CREATE FROM TRANSCRIPT", lambda: shell.navigate("transcript")).pack(side="right")
            danger_button(top, "CLEAR ALL", self.clear_all, width=100).pack(side="right", padx=8)

        self.projects = app.call(access.get_projects) or []
        tasks = sum(p["task_count"] for p in self.projects)
        hours = sum(p["total_hours"] for p in self.projects)
        tiles = [("PROJECTS", str(len(self.projects)), T.CYAN),
                 ("MY TASKS" if role == "AGENT" else "TASKS", str(tasks), T.GREEN),
                 ("EST. HOURS", "{:g}".format(hours), T.MAGENTA)]
        stat_row(self, tiles).pack(fill="x", padx=28, pady=(0, 12))

        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.pack(fill="both", expand=True, padx=20, pady=(0, 16))
        self.cards = []
        if not self.projects:
            msg = {"ADMIN": "No projects yet. Use  ＋ CREATE FROM TRANSCRIPT  to generate them from a meeting.",
                   "MANAGER": "No projects are assigned to you yet.",
                   "AGENT": "No tasks have been assigned to you yet."}[role]
            label(self.scroll, msg, 14, T.MUTED).pack(pady=60)
        for p in self.projects:
            self.cards.append(ProjectCard(self.scroll, p, self.open_project))
        self._cols = 0
        self.bind("<Configure>", self._relayout)
        self.after(50, self._relayout)

    def _relayout(self, _event=None) -> None:
        if not self.cards or not self.winfo_exists():
            return
        cols = max(1, min(4, (self.winfo_width() - 40) // CARD_W))
        if cols == self._cols:
            return
        self._cols = cols
        for c in range(4):
            self.scroll.grid_columnconfigure(c, weight=1 if c < cols else 0, uniform="cards" if c < cols else "")
        for i, card in enumerate(self.cards):
            card.grid_forget()
            card.grid(row=i // cols, column=i % cols, sticky="nsew", padx=8, pady=8)

    def open_project(self, project_id) -> None:
        self.shell.navigate("project", project_id=project_id, back="projects")

    def clear_all(self) -> None:
        if not self.projects:
            return
        if messagebox.askyesno("Clear all projects",
                               "Delete ALL projects and tasks? (Team accounts are kept.)\nThis cannot be undone."):
            if self.app.call(access.clear_all_projects) is not None:
                self.shell.navigate("projects")
