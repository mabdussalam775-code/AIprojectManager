"""Password hashing (PBKDF2-HMAC-SHA256, salted, constant-time compare). Stdlib only."""
from __future__ import annotations

import hashlib
import hmac
import os

ITERATIONS = 200_000
_DUMMY = None


def hash_password(password: str, iterations: int = None) -> str:
    iterations = iterations or ITERATIONS
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return "pbkdf2_sha256${}${}${}".format(iterations, salt.hex(), digest.hex())


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters, salt_hex, hash_hex = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                     bytes.fromhex(salt_hex), int(iters))
        return hmac.compare_digest(digest.hex(), hash_hex)
    except (ValueError, TypeError):
        return False


def burn_time(password: str) -> None:
    """Spend the same time as a real check so unknown emails can't be detected by timing."""
    global _DUMMY
    if _DUMMY is None:
        _DUMMY = hash_password("not-a-real-password")
    verify_password(password, _DUMMY)
