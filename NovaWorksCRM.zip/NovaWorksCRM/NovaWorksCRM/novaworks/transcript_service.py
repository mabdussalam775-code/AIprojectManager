"""createFromTranscript: admin-only, validate-everything-then-save-everything.

Flow  (P projects, T tasks, U users):
  1. auth + ADMIN check                                   O(1)
  2. load directory (no passwords)                        O(U)
  3. AI -> draft JSON                                     external
  4. validate whole draft, save NOTHING if any issue      O(P + T)
  5. one BEGIN IMMEDIATE ... COMMIT transaction           O(P + T)  (rollback on any error)
"""
from __future__ import annotations

import json
import sqlite3
from typing import Any, Dict, List

from . import ai_service, auth, validator
from .access import AccessDenied
from .database import db, transaction


class TranscriptError(Exception):
    pass


def _admin(conn, token: str) -> Dict[str, Any]:
    user = auth.user_for_token(conn, token)
    if user["role"] != "ADMIN":
        raise AccessDenied("Only the administrator can create projects from a transcript.")
    return user


def load_directory(conn) -> List[Dict[str, Any]]:
    rows = conn.execute("SELECT id, name, email, role, specialization, skills FROM users")  # no password_hash
    return [{"id": r["id"], "name": r["name"], "email": r["email"], "role": r["role"],
             "specialization": r["specialization"], "skills": json.loads(r["skills"] or "[]")} for r in rows]


def _validate_and_save(token: str, draft: Any, engine: str) -> Dict[str, Any]:
    with db() as conn:
        _admin(conn, token)                      # re-check: the session may have ended during the AI call
        users = load_directory(conn)
        existing = [(r["name"], r["client_name"]) for r in conn.execute("SELECT name, client_name FROM projects")]
        normalised, issues = validator.validate_draft(draft, users, existing)
        if issues:
            return {"status": "needs_correction", "engine": engine, "issues": issues, "draft": normalised}
        try:
            summary = _save(conn, normalised)
        except sqlite3.Error as exc:             # transaction already rolled back -> nothing partial
            msg = "Database refused the draft ({}). Nothing was saved.".format(exc)
            return {"status": "needs_correction", "engine": engine,
                    "issues": [{"path": "database", "message": msg}], "draft": normalised}
    summary.update(status="created", engine=engine)
    return summary


def _save(conn, clean: Dict[str, Any]) -> Dict[str, Any]:
    created = []
    with transaction(conn):
        for p in clean["projects"]:
            cur = conn.execute(
                "INSERT INTO projects (name, client_name, description, manager_id, deadline) VALUES (?,?,?,?,?)",
                (p["name"], p["clientName"], p["description"], p["managerId"], p["deadline"]))
            pid = cur.lastrowid                  # application-generated id
            conn.executemany(
                "INSERT INTO tasks (project_id, title, description, assignee_id, deadline, estimated_hours) "
                "VALUES (?,?,?,?,?,?)",
                [(pid, t["title"], t["description"], t["assigneeId"], t["deadline"], t["estimatedHours"])
                 for t in p["tasks"]])
            created.append({"id": pid, "name": p["name"], "task_count": len(p["tasks"]),
                            "total_hours": sum(t["estimatedHours"] for t in p["tasks"])})
    return {"projects": created, "project_count": len(created),
            "task_count": sum(c["task_count"] for c in created),
            "total_hours": sum(c["total_hours"] for c in created)}


def create_from_transcript(token: str, transcript: str) -> Dict[str, Any]:
    """Returns {'status': 'created', ...} or {'status': 'needs_correction', 'issues', 'draft'}.
    Raises TranscriptError / AIError / AccessDenied / AuthError for hard failures (nothing saved)."""
    with db() as conn:
        _admin(conn, token)
        directory = load_directory(conn)
    text = (transcript or "").strip()
    if not text:
        raise TranscriptError("The transcript is empty. Paste the meeting transcript first.")
    draft, engine = ai_service.extract_draft(text, directory)     # may raise AIError
    return _validate_and_save(token, draft, engine)


def save_draft(token: str, draft: Any) -> Dict[str, Any]:
    """Re-validate an admin-corrected draft and save it (same all-or-nothing rules)."""
    return _validate_and_save(token, draft, "Admin-corrected draft")
