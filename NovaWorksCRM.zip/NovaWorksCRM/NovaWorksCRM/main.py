"""NovaWorks CRM - AI Project Manager.   Start with:  python main.py"""
from novaworks.ui.app import run

if __name__ == "__main__":
    run()
